
/**
 * The main class of the programe.It will allow the user to start the game. It generally handles all the
inputs and outputs to the user unless another utility class has been included to do this. 
 *
 * @Chao Liu 
 * @version 01
 */
import java.util.ArrayList;
public class Championship
{
    
    private ListOfDrivers drivers;
    private ListOfVenues venues;
    
    /**
     * Constructor for objects of class Championship,initialise instance variables
     */
    public Championship()
    {
       
        drivers = new ListOfDrivers();
        venues = new ListOfVenues();
    }
    
    public Championship(ListOfDrivers newDriver,ListOfVenues newVenue)
    {
    
        newDriver = drivers;
        newVenue = venues;
    }
    
  
    /**
      * the ideas of put array inside arraylist come from :https://stackoverflow.com/questions/41738559/string-inside-arrayliststring
      * the ideas of adding new object into an arraylist reference from :https://www.youtube.com/watch?v=wclenMIVa24
      * After filereader read the file and acquire the attribute inforamtion for each venue, listVenue method is to store the atrributes into 
      * each driver object.
      */
    
    public void listVenue()
    {
       FileIO fileIO= new FileIO();
       fileIO.setFilename("venues.txt");
       ArrayList<String[]> Venue= fileIO.readFile();
       
        for(int i=0;i<Venue.size();i++)
        {
            String []venuelist = Venue.get(i);
            String venueName = venuelist[0];
            int noOfLaps = Integer.parseInt(venuelist[1]);
            int averageLapTime = Integer.parseInt(venuelist[2]);
            double chanceOfRain = Double.parseDouble(venuelist[3]);
            
            venues.addVenue(venueName, noOfLaps, averageLapTime, chanceOfRain);
            
        }
       
    }
    
    /**
    * same as listvenue method, After filereader read the file and acquire the attribute inforamtion for each driver,listdrivers method is to 
    * store the atrributes into each venue object
    */
   public void listDrivers()
    {
        FileIO fileIO= new FileIO();
        fileIO.setFilename("drivers.txt");
        
        ArrayList<String[]> driver = fileIO.readFile();
        
        
        for(int i=0; i<driver.size() ;i++)
        {
            String driverName = driver.get(i)[0];
            int driverRanking = Integer.parseInt(driver.get(i)[1]);
            String driverSpecialSkill = driver.get(i)[2];
          
            drivers.addDriversList(driverName,driverRanking,driverSpecialSkill);
            
        }
       
      }
    
    /**
     * rquestRace method is to request the input of numbers of races and store it.
    */
    public int requestRace()
    {
      System.out.println("Please  enter the number of races in the championship from 3 to 5");
      Input input = new Input();
      Validation validate = new Validation();
      String raceNumber = input.getInput();
     
      while(validate.validateInput(raceNumber) == false|| validate.validateInputLimit(Integer.parseInt(raceNumber),3,5) == false)
        {
              System.out.println("the race number should be a number between 3 to 5, please try again");
              raceNumber = input.getInput();
            }
      int raceNumberC = Integer.parseInt(raceNumber);
      System.out.println("you picked "+raceNumberC+" number of race");
      return raceNumberC;
     }
    
      /**
     * genurateVenue method is to genurate a random venue number to start the race.
     */
    public int genurateVenue(int venueNumber)
     {
        RNG venue= new RNG();
        int v = venue.getRandomNumber(1, venueNumber);
        System.out.println();
        System.out.println("the venue number is "+ v);
        return v;
     }
 
    
      /**
     * weatherForcast Method is to provide the random chance of rain in the begining of each lap. 
     */
    public boolean weatherForecast(double rainPosibility)
    {
        RNG random = new RNG();
        int randomNo=random.getRandomNumber(1, 100);
        boolean rain = true;
        if(randomNo > (int)(rainPosibility*100))
        {
        rain = false;
        }
        
        return rain;
    
    }
    
    
     /**
     * displayVenues method is to display the welcome message at the begining of each race. 
     */
    public void displayVenues()
    {
      System.out.println("The amazing racing venues are ");
       System.out.println("*********************************************");
      for(int i=0;i<venues.getVenueListSize();i++)
      {
          System.out.println(venues.getVenueList().get(i).getVenueName());
        }
       System.out.println("*********************************************");
    }
    
    
    /**
     * displayDriverPosition method is to display each driver's position at the begining of each race. 
     */
     public void displayDriverPosition()
     {
        System.out.println("Today's drivers are ");
        System.out.println("*********************************************");
        for (int i=0;i< drivers.getDriverList().size();i++)
        {
        System.out.println("Position "+drivers.getDriverList().get(i).getRanking() +":"+ drivers.getDriverList().get(i).getName());
        }
          System.out.println("*********************************************");
      }
    
      /**
     * setPenalityTime method is to sort driver by ranking and assign the penalty time according to their ranking. 
     */
    public void setPenaltyTime()
    {
        for (int i=0;i<drivers.getDriverListSize();i++)
        {
            int driverRanking = drivers.getDriverList().get(i).getRanking();
            switch (driverRanking)
            {
                case 1:
                drivers.getDriverList().get(i).setAdditionalTime(0);
                case 2:
                drivers.getDriverList().get(i).setAdditionalTime(3);
                case 3:
                drivers.getDriverList().get(i).setAdditionalTime(5);
                case 4:
                drivers.getDriverList().get(i).setAdditionalTime(7);
                case 5:
                drivers.getDriverList().get(i).setAdditionalTime(10);
            
            
            }
        
        
        }
    
    }
    
    /**
     * setPenalityTime method is to check the driver's skill and assign the scores to driver when the driver was checked to use one sepcific
     * skill . 
     */
    public int driverUseSkill(int noOfLap, int driverPosition, int LapTime)
    {
        String driverSkill = drivers.getDriverList().get(driverPosition).getSpecialSkill();
        if(driverSkill.equals("Braking"))
        {
            RNG random = new RNG();
            LapTime =LapTime - random.getRandomNumber(1, 8);
        
        }
        else if(driverSkill.equals("Cornering"))
        {
           RNG random = new RNG();
           LapTime =LapTime - random.getRandomNumber(1, 8);
        
        }
        else if (driverSkill.equals("Overtaking") && noOfLap % 3==0)
        {
           RNG random = new RNG();
           LapTime =LapTime - random.getRandomNumber(10, 20);
        
        }
    
        return LapTime;
    }
    
    
     /**
     * setPenalityTime method is to check the driver's skill and assign the scores to driver when the driver was checked to use one sepcific
     * skill . 
     */
    public void driverChangeTyers(int driverPosition)
    {
       
        drivers.getDriverList().get(driverPosition).setTyerType(0);
        int lastLapTime = drivers.getDriverList().get(driverPosition).getAdditionalTime();
        int newLapTime = lastLapTime +10;
        drivers.getDriverList().get(driverPosition).setAdditionalTime(newLapTime);
        System.out.println("Driver "+drivers.getDriverList().get(driverPosition).getName()+ "equipped with wet tyre");
     
    
    
    }
    
     /**
     * tyerUnchangePenalty method is to check if driver meet the conditions of chaning wet tyer or not first and assign accordingly penality time. 
     */
    
    public int tyerUnchangePenalty(boolean rain, int driverPosition,int additionalTime)
    {
      if (rain=true && drivers.getDriverList().get(driverPosition).getTyerType()==1)
      {
          additionalTime = additionalTime + 5;
        }
      return additionalTime;
    }
   
    
    /**driverAccident method is to genurate the accidents driver may experience during each lap.
     the idea of this method come from 
     https://gamedev.stackexchange.com/questions/81551/how-can-i-implement-a-percentage-chance-to-perform-some-action
     originally from user000user's comment  edited Aug 8 '14 at 17:27
     */
    
    public int driverAccident(int driverPosition,int lapTime)
    {
        RNG random = new RNG();
        int accidentPossbility = random.getRandomNumber(1, 100);
        if(accidentPossbility >=96)
        {
          System.out.println("bad news!! " + drivers.getDriverList().get(driverPosition).getName()+"encounter a minor mechanical fault!");
          System.out.println("sadlly " + drivers.getDriverList().get(driverPosition).getName()+"need addition 20 seconds due to the fault");
         lapTime=lapTime+20;
        }
    
        else if (accidentPossbility <=3)
          {
          System.out.println("bad news!! " + drivers.getDriverList().get(driverPosition).getName()+"encounter a major mechanical fault!");
          System.out.println("sadlly " + drivers.getDriverList().get(driverPosition).getName()+"need addition 120 seconds due to the fault");
          lapTime=lapTime+120;
        }
         else if (accidentPossbility ==50)
          {
          System.out.println("bad news!! " + drivers.getDriverList().get(driverPosition).getName()+"encounter an unrecovery mechanical fault!");
          System.out.println("sadlly " + drivers.getDriverList().get(driverPosition).getName()+"will quit");
          drivers.getDriverList().get(driverPosition).setEligibleToRace(false);
          
        }
        
        return accidentPossbility;
    }
    
    
     /**driversPoints method is to genurate the accidents driver may experience during each lap.
      * comparing the element from two arraylist reference https://stackoverflow.com/questions/14621445/comparing-two-arraylists-in-java
    */
    
    public void driversPoints()
    {
      for(int i=0;i<drivers.getDriverList().size();i++)
       {
             int isEqual = 0;
             for(int j=i+1;j<drivers.getDriverList().size();j++)
             if (drivers.getDriverList().get(i).getAdditionalTime() == drivers.getDriverList().get(j).getAdditionalTime())
             {
                
                 isEqual=isEqual+1;
                 
              }
             else
             {
               break;
                }
             
             if (isEqual>0)
               {
                int driverPosition;
                 RNG random = new RNG();
                 driverPosition = random.getRandomNumber(i,isEqual);
                 drivers.switchDriverPosition(i, driverPosition);
                
                
               }
                
               System.out.println("---*"+"Rank"+(i+1)+"*---");
               System.out.println(" ** "+drivers.getDriverList().get(i).getName()+" ** ");
               int driverTime= drivers.getDriverList().get(i).getAdditionalTime();
               int driverScore= 0;
              if(drivers.getDriverList().get(i).getLigibleToRace()==true)
              {
                System.out.println(drivers.getDriverList().get(i).getName()+" race time is "+driverTime+"*");
                
            
              }
              else
              {
                driverScore = 0;
                System.out.println(" bad news! driver quit !");
            
               }
               
              if(i==0)
               {driverScore= 8;
                System.out.println("congrats!"+drivers.getDriverList().get(i).getName()+" recieved 8 scores as award for the top ranking");
                }
               else if (i==2)
               {driverScore= 5;
                System.out.println("congrats!"+drivers.getDriverList().get(i).getName()+" recieved 5 scores as award for the second ranking");
                }
                else if (i==3)
               {driverScore= 3;
                System.out.println("congrats!"+drivers.getDriverList().get(i).getName()+" recieved 3 scores as award for the third ranking");
                }
                else if (i==4)
               {driverScore= 1;
                System.out.println("congrats!"+drivers.getDriverList().get(i).getName()+" recieved 1 scores as award for the forth ranking");
                }
             int lastScore = drivers.getDriverList().get(i).getAccumlatedScore();
             drivers.getDriverList().get(i).setAccumlatedScore(driverScore + lastScore);
             System.out.print(drivers.getDriverList().get(i).getName()+"'s accumulated score is "+drivers.getDriverList().get(i).getAccumlatedScore()+" *");
             System.out.println();
            
            
            
            }
            
          
    }
    
    
     /**The displayWinner method is just for print out the winner.
      */
    public void displayWinner()
    {
      drivers.lapTimeOrder();
      System.out.println("the winner is "+ drivers.getDriverList().get(0).getName());
      
      System.out.println("the winner lap time is  "+ drivers.getDriverList().get(0).getAdditionalTime());
    }
    
      /**The displayWinner method is just for print out the champion.
      */
    public void displayChampion()
    {
       drivers.scoreOrder();
         System.out.println("*********************************************");
         System.out.println("***Now it's time to see who is the champion**");
         System.out.println("The Championship isssssssssssss");
        System.out.println("***♔♔♔"+drivers.getDriverList().get(0).getName()+"♔♔♔***");
        System.out.println(drivers.getDriverList().get(0).getName()+" final score is "+ drivers.getDriverList().get(0).getAccumlatedScore());  
       
    }
    
      /**The recordDriverRanking method is to refresh and record the ranking into the file after each race.
       * https://stackoverflow.com/questions/8476830/printwriter-println-no-new-line-created
      */
    public void recordDriverRanking()
    {
    FileIO fileio = new FileIO("drivers.txt");
    fileio.writeFiles("");
    String content="";
    for(int i=0;i<drivers.getDriverListSize();i++)
    {
      
     if (i<4)
      {
          drivers.getDriverList().get(i).setRanking(i+1);
         
        }
        else
        {
            drivers.getDriverList().get(i).setRanking(5);
        }
   
    String name = drivers.getDriverList().get(i).getName();
    int ranking = drivers.getDriverList().get(i).getRanking();
    String skills=drivers.getDriverList().get(i).getSpecialSkill();
    
    if (i==drivers. getDriverListSize()-1)
    {
        content+= name+","+ranking+","+skills;
    }
    else
    {
        content+= name+","+ranking+","+skills+"\r\n";
    }
    
  
    }
   fileio.writeFiles(content);
   }
    

     /**The startRace method is to describe and caclulate the driver's score and time change in each race. 
     */
    public void startRace(int venueNumber)
    {
        Input userInput = new Input();
        String venueName = venues.getVenueList().get(venueNumber).getVenueName();
        int noOfLaps= venues.getVenueList().get(venueNumber).getNoOfLaps();
        int baseLapTime = venues.getVenueList().get(venueNumber).getAverageLapTime();
        double chanceOfRain = venues.getVenueList().get(venueNumber).getChanceOfRain();
       
        System.out.println("What a lovely day! today's race venue is  "+ venueName);
        System.out.println("The total laps in today's race is "+ noOfLaps);
        System.out.println("The average lap time is "+ baseLapTime);
        System.out.println("According to the weather forcast, the chance of rain for today is "+ chanceOfRain);
        System.out.println("*********************************************");
        System.out.println("excited time is coming!the race start!!!");
        System.out.println("*********************************************");
        drivers.rankingOrder();
        setPenaltyTime();
        displayDriverPosition();
     for (int i=1;i<=noOfLaps;i++)
     {
            boolean rain = weatherForecast(chanceOfRain);
            if(rain)
            {
                System.out.println("',',',',',',',',',',',',',',',','");
                System.out.println("how romantic!racing in the rain ");
               
            }
            else
            {
                  System.out.println("..............☼☼☼................");
                  System.out.println("it's a lovely sunny day!! ");
            }
            
        
             System.out.println("*********************************************");
       
             for(int j=0;j<drivers.getDriverListSize();j++)
            {
             if(drivers.getDriverList().get(j).getLigibleToRace() ==true)
             {
              if (i ==2&& rain == true)
              {
                RNG random = new RNG();
                 int randomNumber = random.getRandomNumber(0, 1);
                if (randomNumber ==1)
                {
                  driverChangeTyers(j);
                 }
        
               }
               int lastLapTime = drivers.getDriverList().get(j).getAdditionalTime();
          
               int newLapTime= lastLapTime + baseLapTime;
               newLapTime= driverUseSkill(noOfLaps, j, newLapTime);
               newLapTime= driverAccident(j,newLapTime);
               newLapTime= tyerUnchangePenalty(rain,j,newLapTime);
               drivers.getDriverList().get(j).setAdditionalTime(newLapTime);
           
             }
             else
              {
                drivers.getDriverList().get(j).setAdditionalTime(999999999);
                System.out.println(" driver quit ");
            
               }
           }
           System.out.println("the number "+i+" lap finished");
           displayWinner();
           System.out.println("please hit enter to continue");
           userInput.getInput();
        
     }
         System.out.println("*********************************************");
         System.out.println("The amazing race was end, let's see our driver's score!");
         System.out.println("***************Point Board*******************");
          driversPoints();
          recordDriverRanking();
         System.out.println();
         System.out.println("*********************************************");
         userInput.getInput();
     }
   
     
     /**The main method of the championship class. https://www.youtube.com/watch?v=wclenMIVa24
       */
    public void enterChampionship()
    {
        System.out.println("Welcome to the Wilde Racing game! Are you ready for an adventure race?");
    
        listVenue();
        listDrivers();
        int numberOfRaces = requestRace();
        System.out.println("*********************************************");
        int raceOrder = 1;
        while(numberOfRaces >0)
        {
        displayVenues();
        int venueNumber = genurateVenue(venues.getVenueListSize()-1);
        startRace(venueNumber);
        
        displayChampion();
        venues.getVenueList().remove(venueNumber);
        numberOfRaces--;
        raceOrder++;
        System.out.println("*********************************************");
        
        }
     
    }
    
}
