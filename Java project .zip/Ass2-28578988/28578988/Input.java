
/**
 * Input class is for recieve user's input 
 *
 * @author (Chao Liu)
 * 
 */
import java.util.Scanner;
public class Input
{
    // instance variables 
    private String input;

    /**
     * Constructor for objects of class Input
     */
    public Input()
    {
        // initialise instance variables
        input = "";
    }

    /**
     * getinput method is to recieve uer's input and return it
     */
    public String getInput()
    {
        // put your code here
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        return input;
    }
}
