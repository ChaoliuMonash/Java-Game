
/**
 * RNG class is to store a random number which servie for other class 
 *
 * @author Chao Liu
 * @version (01)
 */
public class RNG
{
    // instance variables - replace the example below with your own
    private int maximumValue;
    private int minimumValue;
    private int random;
    
    /**
     * Constructor for objects of class RNG
     */
    public RNG()
    {
        // initialise instance variables
        maximumValue = 0;
        minimumValue = 1;
    }

     /**
     * get method to generate a random number between min and max.
     */
     public int getRandomNumber(int minimumValue, int maximumValue)
    {
        // put your code here
        int random = (int)(Math.random() * (maximumValue -minimumValue +1));
        return random +minimumValue;
    }
}
