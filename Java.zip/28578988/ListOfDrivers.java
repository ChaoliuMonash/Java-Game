
/**
 * List of driver class stores an arraylist of Driver objects who race in the championship..
 *
 * @ChaoLiu
 * @01
 */
import java.util.ArrayList;
public class ListOfDrivers
{
    // instance variables - replace the example below with your own
    private ArrayList<Drivers> drivers;

    /**
     * default Constructor for objects of class ListOfDrivers
     */
    public ListOfDrivers()
    {
        // initialise instance variables
        drivers = new ArrayList<Drivers>();
    }

      /**
     * non-default Constructor for objects of class ListOfDrivers
     */
    
    public ListOfDrivers(ArrayList<Drivers> driver)
    {
      driver = drivers;
    }
    
     /**
     *addDriverList method is for add new element into the array list of drivers
     */
    
    public void addDriversList(String driverName,int driverRanking, String driverSpecialSkill)
    {
        // put your code here
        drivers.add(new Drivers(driverName,driverRanking,driverSpecialSkill,true,0,0,1));
       
    }
    
    /**
     *get driver list is the accessor to get the driver list 
     */
    public ArrayList<Drivers> getDriverList()
    {
        return drivers;
    
    }
   
    
      /**
     *get driver list is the mutators to set the new driver list 
     */
    public void setdrivers(ArrayList<Drivers> driverList)
    {
        driverList = drivers;
    
    }
    
     /**
     *getDriverListSize method is the accessor to get the driver array  list size
     */
    
    public int getDriverListSize()
    {
      return drivers.size();
    }
    
    
     /**
     *setDriverListSize method is the mutators  to set the driver array  list size
     */
    public void setDriverListSize(ArrayList<Drivers> driver)
    {
      driver=drivers;
    }
  
    
      /**
     *switchDriverPosition is the method for assist the scoreorder, ranking order and time order sort method to switch driver's position.
     */
    
    public void switchDriverPosition(int driver1, int driver2)
    {
       Drivers tempDriver = drivers.get(driver1);
       drivers.set(driver1, drivers.get(driver2));
       drivers.set(driver2,tempDriver);
    }
    
     
     /**
     *display method of the driver list class
     */
    public String display()
    {
        String driverInfo="";
        for(Drivers driver:drivers)
        { 
            driverInfo = driverInfo + driver.display();
        
        }
        return driverInfo;
    }
    
     /**
     *scoreOrder method is to sort driver's order by score.
     *the original code is from   https://www.geeksforgeeks.org/java-program-for-bubble-sort/
     */
 
    public void scoreOrder()
    {
       for (int i=0;i<drivers.size();i++)
       {
           for(int j=i+1;j<drivers.size();j++)
           if(drivers.get(j).getAccumlatedScore()>drivers.get(i).getAccumlatedScore())
           switchDriverPosition(i,j);
           
        }
    }
   
    
    /**
     *scoreOrder method is to sort driver's order by ranking.
     *the original code is from   https://www.geeksforgeeks.org/java-program-for-bubble-sort/
     */
 
      public void rankingOrder()
    {
       for (int i=0;i<drivers.size();i++)
       {
           for(int j=i+1;j<drivers.size();j++)
           if(drivers.get(j).getRanking()< drivers.get(i).getRanking())
           switchDriverPosition(i,j);
           
        }
    }
    
     /**
     *scoreOrder method is to sort driver's order by laptimeorder.
     *the original code is from   https://www.geeksforgeeks.org/java-program-for-bubble-sort/
     */
     public void lapTimeOrder()
    {
       for (int i=0;i<drivers.size();i++)
       {
           for(int j=i+1;j<drivers.size();j++)
           if(drivers.get(j).getAdditionalTime()<drivers.get(i).getAdditionalTime())
           
           switchDriverPosition(i,j);
        }
    }
   
}
