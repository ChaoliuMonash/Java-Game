
/**
 * Validation class is to validate the user's input and catch the exception incase the progrom stop.
 *
 * @author ChaoLiu

 */
public class Validation
{
    
    private boolean validateNumber;

    /**
     * validateinput method is to check and convert the user input into integer and handel the exception of other unexpected form of input
     */
    public boolean validateInput(String input)
    {
        // initialise instance variables
        try
        { 
         
         int result = Integer.parseInt(input);
         return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    /**
     * validateInputLimit method is to check if the number is in the limitated range.
     */
    public boolean validateInputLimit(int inputNumber, int miniNumber,int maxNumber)
    {
        try{
        if(inputNumber < miniNumber || inputNumber >maxNumber)
        {
           return false;
        }
        else
        {
           return true;
        }
        }
         catch(Exception e)
        {
            return false;
        }
      
    }
}
