
/**
 *  FileIO class include the print writer and file reader to read and write the file 
 * @Chao Liu
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.IOException;


public class FileIO
{
    // instance variables - replace the example below with your own
    private String filename;

    /**
     * Defalt Constructor for objects of class 
     */
    public FileIO()
    {
        // initialise instance variables
        filename = "";
    }
    
    /**
     * non-Defalt Constructor for objects of class 
     */
    public FileIO(String newFilename)
    {
        // initialise instance variables
        filename = newFilename;
    }

    
     /**
     * accessor of the file name  of class 
     */
    
    public String getFilename()
    {
        // put your code here
        return filename;
    }
    
     /**
     * mutator of the file name  of class 
     */
    
    public void setFilename(String newFileName)
    {
        // put your code here
        filename= newFileName;
    }
    
    
     /**
     *file reader method 
     */
    public ArrayList<String[]> readFile()
    {
      try
      {
          FileReader inputFile;
          inputFile = new FileReader(filename);
          try{Scanner scanner = new Scanner(inputFile);
          ArrayList<String[]>lines = new ArrayList<String[]>();
          while(scanner.hasNextLine())
          {
            String line = scanner.nextLine();
            String[] variables = line.split(",");
            lines.add(variables);
            }
            return lines;
        }
          finally
        { inputFile.close();
        
        }
          
        }
        
       catch(FileNotFoundException e)
       {
           System.out.println(filename +" unfortunely no result was found");
        
        }
        
        catch(IOException e)
        {
           System.out.println("unexpected error");
        }
        return null;
    }
    
    /**
     * file writer method
     */
    public void writeFiles(String content)
    {
        try
        {
            PrintWriter outputFile;
            
            outputFile = new PrintWriter(filename);
            outputFile.println(content);
            outputFile.close();
       }
       
       catch(FileNotFoundException e)
       {
           System.out.println(filename +" unfortunely no result was found");
        
        }
        
        catch(IOException e)
        {
           System.out.println("unexpected error");
        }
        
    }
}
