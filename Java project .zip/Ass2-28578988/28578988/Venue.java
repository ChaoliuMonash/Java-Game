
/**
 * Venue class describes a single venue for the race. The attributes describe the name, the number of laps
needed at the circuit, the average lap time per lap, and the probability of rain expressed as a
percentage.
 *
 * @author (Chao Liu)
 * e)
 */
public class Venue
{
    // instance variables - replace the example below with your own
    private String venueName;
    private int noOfLaps;
    private int averageLapTime;
    private double chanceOfRain;

    /**
     * Default Constructor for objects of class Venue
     */
    public Venue()
    {
        // initialise instance variables
        String venueName="";
        int noOfLaps = 0;
        int averageLapTime = 0;
        double chanceOfRain = 0;
        
    }
    
    /**
     * Non-Default Constructor for objects of class Venue
     */
    public Venue(String newVenueName, int newNoOfLaps, int newAverageLapTime, double newChanceOfRain)
    {
        // initialise instance variables
        venueName=newVenueName;
        noOfLaps = newNoOfLaps;
        averageLapTime = newAverageLapTime;
        chanceOfRain = newChanceOfRain;
        
    }


    /**
     * getmethod of venue name
     
     */
    public String getVenueName()
    {
        return venueName;
    }
    
    /**
     * getmethod of number of laps
     
     */
    public int getNoOfLaps()
    {
        return noOfLaps;
    }
    
    /**
     * getmethod of number of average lap time
     
     */
    public int getAverageLapTime()
    {
        return averageLapTime;
    }
    
      /**
     * getmethod of chance of rain
     
     */
    public double getChanceOfRain()
    {
        return chanceOfRain;
    }
    
     /**
     * setmethod of venue name
     
     */
    public void setVenueName(String newVenueName)
    {
        venueName = newVenueName;
    }
    
     /**
     * setmethod of number of laps
     
     */
    public void setNoOfLaps(int newNoOfLaps)
    {
        noOfLaps = newNoOfLaps;
    }
    
    /**
     * setmethod of number of laps
     
     */
    public void setAverageOfLaps(int newAverageLapTime)
    {
        averageLapTime = newAverageLapTime;
    }
    
    /**
     * setmethod of number of laps
     
     */
    public void setChanceOfRain(double newChanceOfRain)
    {
        chanceOfRain = newChanceOfRain;
    }
    
      /**
     * display method of this class
     
     */
    public String display()
    {
       String venueInfo= venueName + noOfLaps + averageLapTime+chanceOfRain;
       return venueInfo;
    }
}
