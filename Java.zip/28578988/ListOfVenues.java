/**
 * List of venue class store the arraylist of venue objects where races can be help.
 *
 * @Chaoliu
 * @version 01
 */
import java.util.ArrayList;
public class ListOfVenues
{
    // instance variables - replace the example below with your own
    private ArrayList<Venue> venues;

    /**
     * default Constructor for objects of class ListOfVenues
     */
    public ListOfVenues()
    {
        // initialise instance variables
        venues = new ArrayList<Venue>();
        
    }
    
    /**
     *addVenue method is for add new element into the array list of venue
     */
    public void addVenue(String name,int numberOfLaps,int averageLapTime, double chanceOfRain)
    {
        venues.add(new Venue(name,numberOfLaps,averageLapTime,chanceOfRain));
    
    }
   
    /**
     *get method for venue list size 
     */
    public int getVenueListSize()
    {
      return venues.size();
    }
    
    /**
     *get method for venuelist
     */
    public ArrayList<Venue> getVenueList()
    {
      return venues;
    }
    
     /**
     *set method for venuelist
     */
    public void setVenueList(ArrayList<Venue> venue)
    {
      venue=venues;
    }
 
}
