
/**
 * This class decribes a single drivers in the championships. The attribute include the name, the ranking, a special skills, the driver's 
 * eligibility to race, and the accumulated time.
 * @author (ChaoLiu)
 * @version (01)
 */

public class Drivers
{
    // instance variables - replace the example below with your own
    private String name;
    private int ranking;
    private String specialSkill;
    private boolean eligibleToRace;
    private int accumlatedScore;
    private int additionalTime;
    private int tyerType;
    

    /**
     * defalt Constructor for objects of class Drivers
     */
    public Drivers()
    {
        // initialise instance variables
        String name = "";
        int ranking = 0;
        String specialSkill = "";
        boolean eligibleToRace = true;
        int additionalTime = 0;
        int accumlatedScore =0;
    
        int tyerType = 1;
    
        
    }
    
     
    
    /**
     * non-defalt Condtructor for objects of class Drivers
     */
    
     public Drivers(String driverName, int driverRanking, String driverSpecialSkill,boolean newEligibleToRace,int newAccumlatedScore, 
     int newAdditionalTime,int newTyerType)
    {
        // initialise instance variables
        name =  driverName;
        ranking = driverRanking;
        specialSkill = driverSpecialSkill;
        eligibleToRace = newEligibleToRace;
        additionalTime = newAdditionalTime;
        accumlatedScore = newAccumlatedScore;
     
        tyerType = newTyerType;
        
        
        
        
       
        
    }
    
     /**
     * get method of driver's name 
     */
    public String getName()
    {
        return name;
    }
    
     /**
     * get method of driver's ranking 
     */
    public int getRanking()
    {
        return ranking;
    }
    
     /**
     * get method of driver's sepcial skills
     */
    public String getSpecialSkill()
    {
        return specialSkill;
    }
    
     /**
     * get method of the ligibility of driver
     */
    public boolean getLigibleToRace()
    {
        return true;
    }
    
     /**
     * get method of the accumulated Score
     */
    public int getAccumlatedScore()
    {
        return accumlatedScore;
    }
    
     /**
     * get method of the accumulated Score
     */
    public int getAdditionalTime()
    {
        return additionalTime;
    }
    
      /**
     * get method of the TyerType, 1 means dry tyer,0 means wet tyer
     */
    public int getTyerType()
    {
        return tyerType;
    }
    
     /**
     * set method of driver's name 
     */
    public void setName(String driverName)
    {
        name = driverName;
    }
    
    /**
     * get method of driver's ranking 
     */
    public void setRanking(int driverRanking)
    {
        ranking = driverRanking;
    }
    
     /**
     * set method of driver's sepcial skills
     */
    public void setSpecialSkill(String driverSpecialSkill)
    {
        specialSkill = driverSpecialSkill;
    }
    
    
      /**
     * set method of driver's eligibility to race 
     */
    public void setEligibleToRace(boolean eligibletoRace)
    {
        eligibletoRace = true;
    }
    
    
     /**
     * set method of driver's eligibility to race 
     */
    public void setTyerType(int newTyerType)
    {
        tyerType = newTyerType;
    }
    
     /**
     * set method of driver's AdditionalTime
     */
    
       public void setAdditionalTime(int newAdditionalTime)
    {
        additionalTime = newAdditionalTime;
    }
    
      /**
     * set method of driver's accumulated score
     */
    public void setAccumlatedScore(int newAccumlatedScore)
    {
        accumlatedScore = newAccumlatedScore;
    }
    
       /**
     * display method to display driver's information
     */
    public String display()
    {
        String driversInfo=name + ranking + specialSkill + eligibleToRace + accumlatedScore + additionalTime;
        System.out.println(driversInfo);
        
        return driversInfo;
    }
}
